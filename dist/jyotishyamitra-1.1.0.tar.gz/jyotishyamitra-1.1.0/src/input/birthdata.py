birthdata = { "DOB"     : { "year"     : 0,
                            "month"    : 0,
                            "day"      : 0
                          },
              "TOB"     : { "hour"     : 0,  #in 24 hour format
                            "min"      : 0,
                            "sec"      : 0
                          }, 
              "POB"     : { "name"     : "",
                            "lat"      : 0,     #+ve for North and -ve for south
                            "lon"      : 0,     #+ve for East and -ve for West
                            "timezone" : 0
                          },
              "name"    : "",
              "Gender"  : ""
            }

birthdatastr = { "DOB"  : { "year"     : "",
                            "month"    : "",
                            "day"      : ""
                          },
              "TOB"     : { "hour"     : "",  #in 24 hour format
                            "min"      : "",
                            "sec"      : ""
                          }, 
              "POB"     : { "name"     : "",
                            "lat"      : "",     #+ve for North and -ve for south
                            "lon"      : "",     #+ve for East and -ve for West
                            "timezone" : ""
                          },
              "name"    : "",
              "Gender"  : ""
            }